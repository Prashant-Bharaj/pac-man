"""Pac-Man test suite."""
